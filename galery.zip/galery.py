from flask import render_template, Flask, request
import os
from datetime import datetime


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/galery', methods=['GET', 'POST'])
def galery():
    if request.method == 'POST':
        img_name = datetime.now().strftime('%Y%b%d_%H%M%S')
        img = request.files['file']
        with open(f'static/image/{img_name}.png', 'wb') as output:
            output.write(img.read())
    images = os.listdir(f'{os.getcwd()}/static/image')
    return render_template('galery.html', title='Красная планета', images=images)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
