import flask
from flask import redirect, render_template, jsonify, make_response
from flask_login import LoginManager, login_required
from data import db_session, jobs_api
from data.__all_models import User, Jobs, Department
from forms.user import RegisterForm
from flask_restful import Api, Resource, abort
from forms.login_form import LoginForm
from flask_login import login_user, logout_user

app = flask.Flask(__name__)
api = Api(app)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/')
def jobs_table():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template('jobs_table.html', jobs=jobs, title='Works log')


@app.errorhandler(404)
def not_found(_):
    return make_response(jsonify({'error': 'Not found'}), 404)


def main():
    db_session.global_init(f'db/mars_explorer.sqlite')
    # app.register_blueprint(jobs_api.blueprint)
    # api.add_resourse(NewsResource, 'api/v1/news/<int:news_id>')
    app.run()


def add():
    db_session.global_init(f'db/mars_explorer.sqlite')
    job = Jobs()
    job.team_leader = 2
    job.job = 'jobbbb'
    job.work_size = 20
    job.collaborators = '1, 3'
    job.is_finished = True
    db_sess = db_session.create_session()
    db_sess.add(job)
    db_sess.commit()
    # db_session.global_init(f'db/mars_explorer.sqlite')
    # user = User()
    # user.name = 'Name3'
    # user.surname = 'Surname3'
    # user.age = 20
    # user.address = 'address3'
    # user.email = 'email3@email.com'
    # user.set_password('password3')
    # db_sess = db_session.create_session()
    # db_sess.add(user)
    # db_sess.commit()


if __name__ == '__main__':
    main()
